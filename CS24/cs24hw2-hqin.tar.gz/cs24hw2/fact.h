/*
 * This is a stub header for fact.s
 */
/**
 * Fact is a function that computes the factorial of a given number.
 * @param  n The number to be compute.
 * @return   n!
 */
extern int fact(int n);
